Changelog
==============================

1.1.3 - Jul.09, 2015
------------------------------

- Updated DownloadBill(object).get_bill() for bill downloading

1.1.2 - Jul.08, 2015
------------------------------

- Added class DownloadBill(object) for bill downloading.

1.1.1 - Jun.30, 2015
------------------------------

- Changed get_notification method.
  It will return a more detailed notification dict 
  containning all the information provided.

1.1 - Jun.26, 2015
------------------------------

- Changed verify_merchant_sign_parse_response method.
  It will raise exceptions if get date faild.
  and the return res will macth JD's logic.

1.0 - Jun.15, 2015
------------------------------

- Initail commit

